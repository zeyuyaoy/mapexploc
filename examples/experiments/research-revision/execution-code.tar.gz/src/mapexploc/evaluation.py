"""Evaluation utilities for predictions and explanations."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    confusion_matrix,
    f1_score,
    roc_auc_score,
)


def classification_metrics(
    truth: Any, predicted: Any, probabilities: np.ndarray, classes: list[str]
) -> dict[str, Any]:
    """Score a fixed class universe, with explicitly aligned probability columns.

    Missing-class F1/recall are zero in the fixed macro average. Class AUC/AP
    are undefined (None) without both positive and negative observations.
    """
    actual, guessed = np.asarray(truth), np.asarray(predicted)
    prob = np.asarray(probabilities, dtype=float)
    if len(classes) < 2 or len(set(classes)) != len(classes):
        raise ValueError("Classes must contain at least two unique labels")
    if actual.ndim != 1 or guessed.shape != actual.shape or len(actual) == 0:
        raise ValueError("Truth and predictions must be nonempty aligned vectors")
    if not np.isin(actual, classes).all() or not np.isin(guessed, classes).all():
        raise ValueError("Truth and predictions must use known classes")
    if prob.shape != (len(actual), len(classes)):
        raise ValueError("Probability shape must match rows and classes")
    if (
        not np.isfinite(prob).all()
        or (prob < 0).any()
        or (prob > 1).any()
        or not np.allclose(prob.sum(axis=1), 1, atol=1e-8, rtol=0)
    ):
        raise ValueError("Probabilities must be finite, nonnegative and sum to one")
    one_hot = actual[:, None] == np.asarray(classes)[None, :]
    report = classification_report(
        actual, guessed, labels=classes, output_dict=True, zero_division=0
    )
    matrix = confusion_matrix(actual, guessed, labels=classes)
    per_class = {}
    for i, label in enumerate(classes):
        binary = one_hot[:, i]
        valid = bool(binary.any() and not binary.all())
        negatives = int((~binary).sum())
        fp = int(matrix[:, i].sum() - matrix[i, i])
        per_class[label] = {
            "auroc": float(roc_auc_score(binary, prob[:, i])) if valid else None,
            "average_precision": (
                float(average_precision_score(binary, prob[:, i])) if valid else None
            ),
            "specificity": 1 - fp / negatives if negatives else None,
            "prevalence": float(binary.mean()),
        }
    confidence = prob.max(axis=1)
    correct = np.asarray(classes)[prob.argmax(axis=1)] == actual
    bins = np.minimum((confidence * 10).astype(int), 9)
    reliability = []
    for i in range(10):
        mask = bins == i
        reliability.append(
            {
                "lower": i / 10,
                "upper": (i + 1) / 10,
                "count": int(mask.sum()),
                "accuracy": float(correct[mask].mean()) if mask.any() else None,
                "confidence": float(confidence[mask].mean()) if mask.any() else None,
            }
        )
    return {
        "macro_f1": float(
            f1_score(actual, guessed, labels=classes, average="macro", zero_division=0)
        ),
        "weighted_f1": float(
            f1_score(
                actual, guessed, labels=classes, average="weighted", zero_division=0
            )
        ),
        "balanced_accuracy": float(np.mean([report[c]["recall"] for c in classes])),
        "classification_report": report,
        "confusion_matrix": matrix.tolist(),
        "classes": classes,
        # Calculate true-class loss directly: sklearn log_loss sorts labels,
        # irrespective of a caller's probability-column ordering.
        "log_loss": float(-np.log(np.clip(prob[one_hot], 1e-15, 1)).mean()),
        "multiclass_brier": float(np.square(prob - one_hot).sum(axis=1).mean()),
        "top_label_ece_10_bins": expected_calibration_error(
            correct.tolist(), confidence.tolist()
        ),
        "reliability_bins": reliability,
        "per_class_probability": per_class,
        "macro_auroc": (
            float(np.mean([v["auroc"] for v in per_class.values()]))
            if all(v["auroc"] is not None for v in per_class.values())
            else None
        ),
        "macro_average_precision": (
            float(np.mean([v["average_precision"] for v in per_class.values()]))
            if all(v["average_precision"] is not None for v in per_class.values())
            else None
        ),
    }


def expected_calibration_error(
    y_true: Sequence[int], y_prob: Sequence[float], n_bins: int = 10
) -> float:
    """Compute sample-weighted binary Expected Calibration Error (ECE)."""
    truth = np.asarray(y_true, dtype=float)
    probabilities = np.asarray(y_prob, dtype=float)
    if truth.shape != probabilities.shape or truth.ndim != 1:
        raise ValueError("y_true and y_prob must be one-dimensional and equally sized")
    if len(truth) == 0:
        raise ValueError("At least one prediction is required")
    if n_bins < 1:
        raise ValueError("n_bins must be positive")
    if not np.isin(truth, [0, 1]).all():
        raise ValueError("y_true must contain binary labels")
    if (
        not np.isfinite(probabilities).all()
        or not ((probabilities >= 0) & (probabilities <= 1)).all()
    ):
        raise ValueError("y_prob must contain finite probabilities between 0 and 1")

    bins = np.minimum((probabilities * n_bins).astype(int), n_bins - 1)
    error = 0.0
    for bin_index in range(n_bins):
        mask = bins == bin_index
        if mask.any():
            error += float(mask.mean()) * abs(
                float(truth[mask].mean()) - float(probabilities[mask].mean())
            )
    return error


def aopc(scores: Sequence[float]) -> float:
    """Area over the Perturbation Curve (AOPC)."""
    scores_array = np.asarray(scores)
    if scores_array.size == 0:
        raise ValueError("At least one perturbation score is required")
    return float(scores_array.mean())


def insertion_deletion(reference: Sequence[float], perturbed: Sequence[float]) -> float:
    """Faithfulness metric comparing reference and perturbed outputs."""
    reference_array = np.asarray(reference)
    perturbed_array = np.asarray(perturbed)
    if reference_array.shape != perturbed_array.shape or reference_array.size == 0:
        raise ValueError(
            "Reference and perturbed outputs must be non-empty and aligned"
        )
    return float(np.abs(reference_array - perturbed_array).mean())


__all__ = ["expected_calibration_error", "aopc", "insertion_deletion"]
