# External falsification study: protocol v1

**Status: exact model and analysis specification frozen locally; recruitment,
independent registration, human adjudication and external evaluation are pending.**
The active execution lock is `freeze-v1.1.json`; the original manifest is preserved.
See [maintenance change control](research-software.md#pre-evaluation-maintenance-revision-11).
No external test prediction, new fitted model or wet-lab outcome has been produced
in this stage. The current internal gain remains unconfirmed externally.

The principal next experiment is a single prospective, independently annotated,
homology-screened evaluation of the already fitted logistic system. A failure
will constrain or overturn the claim that its internal advantage transports to
this population. Further internal tuning cannot substitute for this experiment.
The complete machine-readable specification is
`config/external-validation-v1.json`; the local lock and material are under
`examples/validation/external-v1/`. This is not a claim of public preregistration.

## Frozen systems and scientific question

The logistic artifact is
`examples/experiments/research-revision/final/model.joblib`, SHA256
`e760d2ec4ab99d64d495cbb81307c4bf4302e04366fd807745d4680c83e67943`.
It was already fitted on 1,741 development proteins. Keep all fitted coefficients,
intercepts, standardization parameters and feature definitions exactly as stored:
23 global features plus 40 first/last-50-residue composition features, log1p length,
standardization, multinomial logistic regression, C=0.1, lbfgs, temperature=1.
No fitting, calibration, feature revision, confidence threshold, abstention rule
or external-data normalization is permitted. Prediction is softmax followed by
argmax; ties use stored class order: Cytoplasm, Membrane, Mitochondrion, Nucleus,
Secreted. The exact 63 features and fitted-array fingerprints are in `freeze-v1.1.json`.

The fixed comparator is the previously served forest,
`examples/models/human-baseline.joblib`, SHA256
`cd8ecb31c3c177efcf136fa84791839c6ca185ce3525a77aae9155a87b062082`.
It is not refitted. This compares two particular frozen systems with different
development histories and training samples; it cannot establish a causal advantage
of the logistic algorithm over forests. It also differs from the refitted outer-fold
reference used in internal cross-validation. Do not equate those comparisons.

The lock pins code, both artifacts, dependencies, protocol, preparation inputs and
forms. The forest was serialized with scikit-learn 1.9.0; inference is pinned to
1.9.1. A six-sequence synthetic check compares its predictions with direct traversal
of stored trees under the frozen scaler. This is a numerical compatibility check,
not a biological result or a guarantee about arbitrary version changes. The
historical experiment archive and deployed model selection remain unchanged.

## Single primary estimand and decisions

The sole primary estimand is **paired external macro-F1 difference, frozen logistic
minus frozen forest**, over the five fixed classes, among all eligible, adequately
observed, single-label proteins in the precommitted assay source frame. Each protein
has weight one. Class prevalence is that of this eligible source frame. Macro-F1
is still prevalence-dependent; it is not automatically a proteome-wide estimand.

The single primary interval is a two-sided 95% paired percentile bootstrap interval,
10,000 draws, seed 20260919. Resample entire connected dependence components, retaining
all their proteins and paired predictions. Components join shared genes, exact or
related sequences/domains, studies/raw datasets, assay runs and batches. Do not
stratify individual proteins by class. Keep and count class-absent replicates;
the fixed-class F1 convention is zero when its denominator is zero. If more than
1% of draws lack any class, report inadequate uncertainty and make no confirmatory
claim. Do not redraw unfavorable or inconvenient replicates.

Let [L,U] be the interval for the difference and let 0.03 be the predeclared practical
margin. This is an operational research-value threshold, not an established biological
or clinical minimum important difference.

| Observed interval         | Permitted primary conclusion                                                                   |
|---------------------------|------------------------------------------------------------------------------------------------|
| U ≤ 0                     | The apparent gain does not transport; the direction is overturned for this external population |
| 0 < U < 0.03              | The prespecified material gain is ruled out, even if a small positive effect remains possible  |
| L > 0.03                  | Material advantage supported for these frozen systems in this population                       |
| 0 < L ≤ 0.03 and U ≥ 0.03 | Positive advantage supported; material magnitude uncertain                                     |
| Otherwise                 | Inconclusive; external confirmation has not been established                                   |

Failure externally does not erase the earlier internal observation; it limits its
generalization. Neither a favorable point estimate nor a nonsignificant difference
is evidence of equivalence. The interval conditions on the fitted systems, sampling
frame and adjudicated reference standard. It excludes training randomness, annotation
error and unobserved dependence. Strong components reduce the effective sample size.

## Recruitment, support and sample size

Use newly acquired underlying assay data strictly after **2026-09-19 00:00 UTC**.
A new publication date, revised database record or new analysis of old images is
insufficient. Before acquisition and annotation, an independent custodian must
commit named sources/sites, acquisition end date, complete ascertainment, contexts,
sequence-attribution rules and the precision analysis to an independently timestamped
registration. That commitment is deliberately not fabricated here: no contributing
laboratories or external cohort have been supplied or recruited.

Use a consecutive complete frame of assayed proteins, recording failed experiments
and unresolved annotations. Do not choose cases by model scores, familiar/easy
examples, or success at a particular label. No class caps, quota downsampling or
source replacement after scores are observed. Acquisition ends on the committed
date; feasibility failure is reported, not repaired by inspecting predictions and
extending recruitment. Prefer workflows that measure multiple compartments in the
same sources, rather than making class synonymous with laboratory or assay.

Primary support requires human, full native canonical sequences with only the 20
standard residues, length 51–5,654 inclusive (development minimum/maximum), adequate
assay-to-sequence attribution, stated cell type/condition and adequate detection
breadth. Length support is a narrow applicability rule, not proof of multivariate
distributional support. Homology/gene/publication/assay independence must be clear.
Do not infer canonical-isoform attribution from a gene symbol, shared peptide or
antibody signal. Retain fragments, uncertain isoforms, unsupported residues,
partial observations and outside-length cases in the exclusion accounting.

Feasibility floors are 100 primary proteins per class, at least 10 joint components
per class and 20 overall, and no component containing over 20% of any class. These
are gates, not quotas and not sufficient power guarantees. Every eligible protein
in the committed frame is retained, including surplus majority-class proteins.

The supplied `precision-design.json` contains **synthetic design scenarios only**:
900 simulated cohorts across three sizes and three assumed gains, with 400 bootstrap
draws per simulation. It assumes nonuniform class proportions, correlated paired
errors, homogeneous class clusters and a simplified shared error process. It does
not use external outcomes or fit the frozen models.

| Assumed scenario                                                | 500 proteins, independent | 1,000 proteins, clusters of 5 | 2,000 proteins, clusters of 5 |
|-----------------------------------------------------------------|--------------------------:|------------------------------:|------------------------------:|
| Median interval width at approximately +0.06 true macro-F1 gain |                     0.071 |                         0.058 |                         0.041 |
| Fraction supporting gain >0.03 in that scenario                 |                      0.38 |                          0.61 |                          0.84 |
| Fraction with ≥100 cases in every class in that scenario        |                      0.00 |                          0.71 |                          1.00 |

There are only 100 replicates per scenario: the Monte Carlo standard error of 0.84
is about 0.037. These results reject the idea that “500 total” guarantees adequate
class coverage or precision. They do not establish that 2,000 usable independent
human proteins can be recruited. The custodian must run a source-specific design
before annotation, varying prevalence, paired errors, cluster size/dependence and
adjudication loss. Aim for at least 80% detection of a truly +0.06 effect above the
0.03 margin and adequate interval coverage under zero/small effects. If infeasible,
label the study a precision-limited falsification test; do not promise confirmation.

## Reference standard and multilocalization

The mapping is frozen before adjudication. Cytoplasm means supported cytosolic or
diffuse soluble cytoplasmic localization, not every organelle outside the nucleus.
Membrane means plasma membrane; it does not include arbitrary organelle membranes.
Mitochondrion includes matrix, intermembrane space and mitochondrial membranes.
Nucleus includes nucleoplasm, nucleolus and intranuclear bodies. Secreted requires
demonstrated secretion of the assayed protein into the extracellular space, with
controls that address cell lysis. Full mapping and explicit exclusions are in JSON.

ER, Golgi, lysosome, peroxisome, unspecified membranes, ambiguous nuclear envelope
and other compartments are retained as `other_locations`. A signal peptide,
serum detection or imported extracellular database term is not sufficient secretion
evidence. Secretory transit alone is not stable residence; demonstrated additional
residence is retained. Distinguish the native precursor sequence supplied to the
model from processed-fragment evidence, and exclude ambiguous attribution.

Each protein receives a **set** of supported localizations in a specified context,
plus other compartments and a resolved/unresolved status. Cytoplasm/Nucleus may
legitimately remain a two-label set. One positive compartment measurement does not
prove absence elsewhere. Targeted organelle enrichment with unmeasured alternatives
is partial evidence. A primary single-label case needs adequately sensitive,
complementary evidence distinguishing alternatives in that context; it does not
assert exclusive localization in every tissue or condition.

All supported multilocalization stays in the dataset. It is excluded only from the
single-label primary estimand and reported in its own stratum. Its prespecified
descriptive endpoint is whether top-1 lies in the supported label set. This is not
complete multilabel accuracy or a proper scoring rule for unknown absences. Report
the proportion retained in primary, multilocalized, unresolved, unsupported and
dependent strata, by source and available class evidence. Large attrition sharply
narrows generalizability; never present the single-label result as whole-proteome
localization performance.

## Independent blinded adjudication

Two qualified localization reviewers independently review every external case using
primary assay evidence, not imported database labels. Their initial decisions are
timestamped and locked separately before comparison. Both are blind to predictions,
confidence, the earlier curated class, selection trigger and the other's decision.
A third distinct model-blind reviewer resolves disagreements, retaining uncertainty
or multilocalization where appropriate. Record reviewer identities, evidence cited,
assayed sequence/isoform, cell context, reagent controls, detection breadth, notes,
ambiguity, supported sets and rationale. A nominally experimental evidence code is
not a substitute for reading the experiment.

The separate internal annotation audit covers **all 2,107 accepted records**. This
includes all **269** Cytoplasm/Nucleus disagreements found in either saved out-of-fold
repeat of the final logistic configuration and all **381** note-bearing records; their union
is **588**. Reviewing the complete cohort also covers ambiguity not detectable by
a note-presence rule and obscures why any one case was selected. No historical test
predictions were newly generated. These internal cases are not external validation.

`annotation/reviewer-a.csv` and `reviewer-b.csv` omit prior labels, probabilities,
predictions, split status and trigger flags. Only the custodian receives
`custodian-key.json`. **Do not give reviewers this repository or the containing
directory:** they contain the key and model results. Forms contain accession,
sequence and citations; a custodian must prepare primary-evidence dossiers stripped
of model information and inherited curated assignments. Reviewer access to UniProt
or old project results can compromise label blinding and must be documented. The
blank dossier fields are intentional; packets are templates, not completed reviews.
Automated or same-analyst rereading is not counted as independent human adjudication.

The current number of completed independent reviews is **zero**. After the external
labels are sealed and the one-shot results disclosed, all external Cytoplasm/Nucleus
disagreements and note/ambiguity-dependent cases receive a further blind review by
a separate team, mixed with controls. Preserve the original primary labels/results.
Any corrected-label sensitivity analysis is secondary, disclosed as triggered by
test inspection, and cannot replace the primary result or guide model changes.

## Dependence audit

1. Compare against the union of **2,107** development and historical-related proteins,
   including every original 1,822 baseline record. Restricting comparison to fitted
   training rows would ignore data that influenced methodological decisions.
2. Screen exact sequence/accession and gene/isoform identity. The original snapshot
   lacks gene, assay and acquisition metadata; a versioned crosswalk and primary
   provenance audit are mandatory. Unknown identity is unresolved, not clear.
3. Run bidirectional-equivalent all-versus-all MMseqs2 screening on evaluation,
   history and all **20,431** source sequences, including curation-rejected bridge
   proteins. Accept global edges at ≥30% identity and ≥80% coverage of both sequences;
   also accept local edges at ≥30% identity, ≥80 residues, ≥50% coverage of the shorter
   sequence and E≤1e-5. Symmetrize and take connected components. Any connection to
   history excludes primary evaluation. Save every alignment, command and hash.
4. Independently audit remote/domain relationships using a pinned profile database
   and tool version. Shared confidently assigned Pfam families at gathering thresholds,
   ≥50 aligned residues and ≥50% profile coverage are excluded from primary. Review
   shared clans, repeats and uncertain matches blind to model results. An unresolved
   relationship is outside primary. Optionally precommit profile-profile or structural
   checks before annotation. No search result proves absence of remote homology.
5. Normalize PMID/DOI/preprint links and trace source figures/raw datasets; compare
   all supporting publications, reused images/specimens and assay runs. Also audit
   laboratories, cell lines, treatment, reagent/antibody lots, image batches and
   annotation personnel/workflows. Shared cell-line names alone are context overlap,
   whereas shared specimen or experimental batches are direct dependence. Report
   both. A new database hosting the same experiment is not a new validation source.
6. Within the external cohort, join family/gene, publication/raw-data, assay-run and
   batch components transitively for uncertainty and influence analysis. Components
   can span classes. Identifiers refer to experiments, not broad assay names such as
   “immunofluorescence”; genuinely singleton assignments need positive audit evidence.

The sequence script is implemented. External cross-screening has **not** been run
because no external cohort is present. MMseqs2 is available locally; HMMER/profile
and structural screening tooling/databases are not yet installed. Their absence
leaves those checks unresolved and blocks evaluation; it is not a negative result.

## Source feasibility and third-party predictors

HPA may supply useful raw imaging evidence but cannot be declared independent by
database name. Its methods explicitly use UniProt agreement in reliability scoring;
review raw assay provenance rather than importing “Supported” as independent truth.
HPA also does not, by intracellular imaging alone, supply a secretion assay for the
fifth class. [HPA primary methods](https://www.proteinatlas.org/humanproteome/subcellular/method)

OpenCell provides an endogenous-tagging assay source worth considering for a
separately specified assay-separated study, but its existing 2022 data are not
prospectively acquired after this lock. Its publication/raw data, proteins, homology,
sequence attribution and label coverage still require screening. It cannot fill this
primary cohort by relabeling old measurements as new.
[OpenCell primary study](https://pubmed.ncbi.nlm.nih.gov/35271311/)

Before any external predictor runs, freeze its version/checkpoint, preprocessing,
native thresholds, class meanings and handling of outside-map output. Audit its
supervised training sequences/labels and homologs, benchmark selection history and
unlabeled pretraining overlap separately. Unknown training provenance is reported
as unknown; no independence claim follows. DeepLoc 2.0, for example, predicts ten
potentially simultaneous locations, trains on experimentally annotated UniProt
proteins and provides an HPA test set. Neither ten-label outputs nor that published
HPA benchmark can be assumed directly comparable or independent here.
[Developer documentation](https://services.healthtech.dtu.dk/services/DeepLoc-2.0/)

Do not renormalize independent multilabel probabilities into a five-class softmax,
discard incompatible outcomes, or tune thresholds on this test. If semantic/training
compatibility cannot be established, omit the quantitative comparison. Any compatible
comparison is descriptive and separate from the one primary fixed-system comparison.
**No state-of-the-art claim is supported by the present experiments.**

## Biological validation is a separate experiment

Annotation adjudication determines what existing evidence supports. Genuine
confirmation requires appropriate endogenous localization assays in relevant cells
and conditions, with independent biological replicates, blinded analysis, controls
and assay-specific quantitative decision rules. No such new outcomes exist here.

Prefer validated endogenous-antibody imaging with genetic depletion/knockout
specificity controls or carefully validated endogenous tagging. Record isoforms,
expression, cell viability, organelle markers, fraction purity and detection limits;
use orthogonal biochemical or imaging evidence where possible. For Cytoplasm/Nucleus,
combine compartment-resolved imaging with controlled nuclear/cytosolic fractionation
and condition/cell-cycle information. For secretion, distinguish release from lysis,
shedding and extracellular adsorption; use appropriate medium, viability and
intracellular contamination controls. Plasma membrane assays must distinguish surface
association from internal membranes; mitochondrial assays need suitable compartment
markers and purity controls.

Preserve native N- and C-terminal targeting information, signal peptides, processing
sites, transmembrane segments and retention motifs. Overexpressed fragments or a
terminal fusion that disrupts targeting cannot confirm the native-sequence prediction.
Choose and validate tag position per protein; where an internal small tag cannot
be justified, use an orthogonal untagged assay. Endogenous expression alone does not
prove a tag is innocuous. N- versus C-terminal tagging discrepancies have been
observed experimentally. [Primary comparison study](https://www.nature.com/articles/nmeth.2377)

## Execution, artifacts and change control

Use the Python/dependency versions pinned in `freeze-v1.1.json`, from the repository root.
The interpreter for this execution is `.venv/bin/python3.14`. Keep the archived
research-revision execution snapshot to reproduce older runs; adding this new module
changes the live package implementation hash and must not rewrite old run hashes.

```bash
MPLCONFIGDIR=/tmp/mapexploc-mpl PYTHONPATH=src .venv/bin/python3.14 -m mapexploc.external_validation verify
```

An independent custodian creates a **new working bundle**, copying the JSON templates
and adding all candidate records, separately locked reviews, recruitment registration
and provenance reports. Never edit the frozen blank forms. Normalize study IDs as
`PMID:<id>` plus DOI/preprint aliases in the audit. Retain all candidates and all
exclusion reasons; use `case.json` as the row schema. An adjudicator object uses the
review schema and is mandatory whenever initial reviewers differ.

Save each original review as a separate JSON object containing `case_id` and all
review fields, including `submitted_at`. In `provenance.json`, populate
`review_submissions[case_id][reviewer_id]` with its bundle-relative `path` and
`sha256`. The seal compares the merged review to the original file; third-reviewer
timestamps must follow both initial submissions. Independent timestamps and access
control still need an accountable custodian.

```bash
MPLCONFIGDIR=/tmp/mapexploc-mpl PYTHONPATH=src .venv/bin/python3.14 scripts/screen_external_homology.py --cohort /path/to/bundle/cohort.json --output /path/to/new-screen-output
MPLCONFIGDIR=/tmp/mapexploc-mpl PYTHONPATH=src .venv/bin/python3.14 -m mapexploc.external_validation seal --bundle /path/to/bundle
# Only after independent verification and the complete pre-analysis seal:
MPLCONFIGDIR=/tmp/mapexploc-mpl PYTHONPATH=src .venv/bin/python3.14 -m mapexploc.external_validation evaluate --bundle /path/to/bundle
```

The sequence output alone is insufficient to seal. Required reports cover sequence,
remote domains, genes, publications, assays, within-cohort dependencies, bridges,
source-frame completeness and precision design, with hashes, methods and accountable
reviewers. Seal verifies records and creates `cohort-audit.json` and `seal.json`.
Missing metadata or unsupported class/group counts stops the workflow before prediction.
The seal checks the sequence report's candidate-sequence fingerprint and both frozen
reference hashes, rejects contradictory independence flags, and requires every
screened `sequence_component` in that case's `family_ids` as
`sequence:<sequence_component>`. Annotation fields may be completed after screening
without rerunning alignments; the sequence fingerprint and case IDs must remain
identical. Unsupported sequences remain recorded as unscreenable, never clear.

Evaluation exclusively creates a **study-level** `primary-evaluation-started.json`
under the canonical `examples/validation/external-v1/` directory before prediction,
plus a bundle receipt. Reusing a different bundle or copying the freeze file does not
bypass the same local study receipt. It saves predictions, fixed-class primary/secondary
metrics, paired intervals, leave-one-component-out differences and completed-output
hashes. Sign reversal after removing a component is reported as fragility, without
deleting the component or rerunning model selection.

Filesystem hashes and declarations are audit controls, not independent signatures,
proof of biological independence or tamper-proof escrow. A person with filesystem
control could delete receipts or invent attestations. Independent custodianship,
dated registration and access separation remain essential. Preserve failed-attempt
receipts. A technical failure requires a documented independent recovery decision;
it must not become an opportunity to change outcomes, cohorts or the model.

## Work ledger and remaining gates

| Experiment / task                       | Hypothesis                                                              | Change / evaluation                                                                      | Result                                                                                      | Interpretation                                                    | Decision                                                     |
|-----------------------------------------|-------------------------------------------------------------------------|------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------|-------------------------------------------------------------------|--------------------------------------------------------------|
| EV01 Exact freeze                       | The selected system can be held fixed                                   | Hash model, scaler, coefficients, features, code and dependencies                        | Original logistic artifact retained                                                         | No new learning                                                   | Freeze                                                       |
| EV02 Source independence review         | Public alternate annotations may offer independent truth                | Read HPA/OpenCell and predictor methods                                                  | Annotation reuse and temporal/class-coverage limitations                                    | New database alone is insufficient                                | Require primary assay provenance; prioritize new acquisition |
| EV03 Internal review inventory          | All known conflicts/notes can be captured without score-based selection | Prepare complete 2,107-record blind forms                                                | 269 C/N conflicts, 381 note-bearing, 588 union; zero completed reviews                      | Forms are ready for dossier preparation, not adjudication results | Independent reviewers required                               |
| EV04 Precision scenarios                | 500 proteins suffice for all-class, material-gain confirmation          | 900 synthetic cohorts, cluster-aware paired intervals                                    | Class coverage and precision often inadequate; 2,000 improves only under stated assumptions | No universal sample-size guarantee                                | Require recruitment-specific precision justification         |
| EV05 Guardrail tests                    | Invalid cohorts can reach scoring or a test can repeat accidentally     | Synthetic tests for leakage, labels, dependence, missing classes, tampering and receipts | Assertions exercise fail-closed workflow                                                    | Software validation only                                          | Retain safeguards                                            |
| EV06 External principal test            | Internal gain transports to independent prospective data                | Locked study awaiting cohort                                                             | Not run                                                                                     | No external confirmation                                          | Do not replace with additional internal experiments          |
| EV07 Endogenous biological confirmation | Native localization supports selected biological hypotheses             | No new wet-lab assay                                                                     | Not performed                                                                               | Annotation review cannot supply this outcome                      | Separate controlled experiment                               |

Essential outstanding gates: named independent custodian and qualified reviewers;
independently registered recruitment frame; adequate newly acquired assays spanning
all five classes; evidence dossiers and locked adjudication; sequence/gene/domain/
publication/raw-assay audits; and successful cohort/precision checks. No reviewer
was contacted and no external assay cohort was invented. Computationally addressable
items include profile-tool installation, crosswalks, screening and report assembly.
New assay access, native-sequence attribution and independent expert review require
external evidence/resources. A lack of feasible independent all-class cases is a
study limitation, not grounds to loosen eligibility after seeing performance.

## Methods-ready specification

We will evaluate two prespecified, already fitted protein-localization systems once
on all eligible canonical human proteins from an independently registered prospective
assay frame. Neither model will be retrained, tuned or recalibrated. Two independent
model-blind reviewers will assign context-specific localization sets from primary
assay evidence, with third-reviewer resolution and retained multilocalization and
uncertainty. Exact, gene, close/local/remote family, publication and raw-assay overlap
with the complete development/history universe will exclude primary evaluation.
The sole primary estimand will be the paired five-class macro-F1 difference on the
adequately observed single-label stratum, with a 95% interval from 10,000 paired
joint-component bootstrap draws. All exclusions, multilocalization, class coverage,
calibration diagnostics and component influence will be reported. Failure to support
a positive or prespecified 0.03 material gain will constrain the internal claim;
secondary comparisons will not replace the primary result. No wet-lab or
state-of-the-art confirmation is implied by the present computational work.
